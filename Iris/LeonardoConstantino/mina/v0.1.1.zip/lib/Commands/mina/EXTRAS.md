# Informações extras sobre o jogo:

## Estrutura do projeto:

Abaixo esta a lista de arquivos e pastas do projeto.
Você pode alterar o que quiser, mas lembre-se de que o arquivo principal é o index.js

### Principais arquivos que você pode querer alterar:

- **constants.js** - ```/mina/src/utils/constants.js``` - Arquivo de constantes. você pode querer substituir alguns valores.

- **gameMessages.js** - ```/mina/src/utils/gameMessages.js``` - Arquivo de mensagens de jogo. você pode querer substituir alguns diálogos.

## Pastas e arquivos do projeto:
```
📦mina                            # Pasta raiz
 ┣ 📂src                          # Arquivos fontes
 ┃ ┣ 📂game                       # Arquivos de estado e manipulação
 ┃ ┃ ┣ 📜gameState.js             # Estado do jogo
 ┃ ┃ ┗ 📜handleGameState.js       # Manipulação do estado
 ┃ ┗ 📂utils                      # Arquivos de utilitários
 ┃ ┃ ┣ 📂Cache                    # Cache
 ┃ ┃ ┣ 📜constants.               # Constantes
 ┃ ┃ ┣ 📜drawCanvas.js            # Gera imagem do jogo
 ┃ ┃ ┣ 📜gameMessages.js          # Mensagens de jogo
 ┃ ┃ ┣ 📜gameUtils.js             # Utilitários de jogo
 ┃ ┃ ┣ 📜generateGameStats.js     # Gera as estatísticas do jogo
 ┃ ┃ ┣ 📜helpMenu.js              # Menu de ajuda
 ┃ ┃ ┗ 📜utilsArks.js             # Utilitários para a string Arks
 ┣ 📜.game                        # Arquivo de identificação no menu
 ┣ 📜EXTRAS.md                    # Arquivo de EXTRAS
 ┣ 📜index.js                     # Arquivo principal
 ┗ 📜utils.json                   # Arquivo de configuração
```

# Notas das versões

## version: 0.1.0
- Jogo disponibilizado com funções básicas.

## version: 0.1.1
- Adicionado a opção de jogar selecionando somente o numero da célula.
- Adicionado o modo de escolher o tipo de jogo, texto, imagem ou figurinha.
- Adicionado modo de sair de um jogo em andamento.
- Alguns diálogos do jogo foram melhorados.
- Menu de ajuda aperfeiçoado.
- Modificado o modo de seleção de dificuldade, antes eram 5 valores fixos e agora sao valores progressivos.
- Adicionado a configuração de instalação de fontes com emojis no instruct.json
- Algumas outras refatorações, melhorias e correções de bugs.
- Adicionado documentação.

### TODO
- Adicionar ranking local de jogadores.

#### Se precisar de alguma informação sobre o projeto estou a disposição, avise-me!