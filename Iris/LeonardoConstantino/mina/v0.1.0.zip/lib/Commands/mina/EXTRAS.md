# Informações extras sobre o jogo:

## Estrutura do projeto:

Abaixo eta a lista de arquivos e pastas do projeto.
Você pode alterar o que quiser, mas lembre-se de que o arquivo principal é o index.js

### Principais arquivos que você pode querer alterar:

- **constants.js** - ```/mina/src/utils/constants.js``` - Arquivo de constantes. você pode querer substituir alguns valores.

- **gameMessages.js** - ```/mina/src/utils/gameMessages.js``` - Arquivo de mensagens de jogo. você pode querer substituir alguns diálogos.

## Pastas e arquivos do projeto:
```
📦mina                            # Pasta raiz
 ┣ 📂src                          # Arquivos fontes
 ┃ ┣ 📂game                       # Arquivos de estado e manipulação
 ┃ ┃ ┣ 📜gameState.js             # Estado do jogo
 ┃ ┃ ┗ 📜handleGameState.js       # Manipulação do estado
 ┃ ┗ 📂utils                      # Arquivos de utilitários
 ┃ ┃ ┣ 📂Cache                    # Cache
 ┃ ┃ ┣ 📜constants.               # Constantes
 ┃ ┃ ┣ 📜drawCanvas.js            # Gera imagem do jogo
 ┃ ┃ ┣ 📜gameMessages.js          # Mensagens de jogo
 ┃ ┃ ┣ 📜gameUtils.js             # Utilitários de jogo
 ┃ ┃ ┣ 📜generateGameStats.js     # Gera as estatísticas do jogo
 ┃ ┃ ┣ 📜helpMenu.js              # Menu de ajuda
 ┃ ┃ ┗ 📜utilsArks.js             # Utilitários para a string Arks
 ┣ 📜.game                        # Arquivo de identificação no menu
 ┣ 📜EXTRAS.md                    # Arquivo de EXTRAS
 ┣ 📜index.js                     # Arquivo principal
 ┗ 📜utils.json                   # Arquivo de configuração
```

# Notas das versões

## version: 0.1.0
- Jogo disponibilizado com funções básicas.

### TODO
- Adicionar ranking de jogadores.

#### Se precisar de alguma informação sobre o projeto estou a disposição, avise-me!