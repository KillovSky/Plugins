# Jogo de cartas 21 (Blackjack)

## version: 0.1.1
### notas da versão:
- Corrigido bug de não de nao conseguir entrar em uma partida em grupo nao finalizada.

- Adicionado estilização nas mensagens do jogo e nas mensagens de ajuda.

- Adicionado comando para ver quem esta jogando em uma partida em grupo {prefixo}21 -jogadores.

- Adicionado sistema de ganhos e perdas, as partidas agora valem **Í-Coins!**.

- A imagem do joker agora é uma imagem mais neutra.

- Alterado o nome do joker para "Joker", no arquivo de configuração.

### TODO
- Adicionar ranking de jogadores
- Adicionar sistema para punir jogadores inativos nos jogos em grupo.

## Descrição
Jogo de cartas 21 (Blackjack) feito para o bot Iris

## Instalação
Para instalar e rodar no seu bot Iris siga os passos abaixo:

### Instalação manual
Baixe o 21.zip e descompacte-o na pasta ```Iris/lib/Commands```

### Instalação via plugins da Iris
Ainda em desenvolvimento

## Uso
Após a instalação, com sua Iris ativa, digite o comando ```/21 --help``` para ver os comandos disponíveis.

## Estrutura do projeto:

Abaixo eta a lista de arquivos e pastas do projeto.
Você pode alterar o que quiser, mas lembre-se de que o arquivo principal é o index.js

### Principais arquivos que você pode querer alterar:

- **joker.png** - ```/21/src/img/joker.png``` - Imagem de joker. Você pode usar a sua imagem de joker. É recomendado que seja uma imagem quadrada e de 100x100px no formato png. Fora disso você tera que alterar o código para que a imagem seja carregada corretamente.

- **constants.js** - ```/21/src/utils/constants.js``` - Arquivo de constantes. você pode querer substituir alguns valores. Como o nome do seu bot na carta coringa. no máximo 10 caracteres.

- **gameMessages.js** - ```/21/src/utils/gameMessages.js``` - Arquivo de mensagens de jogo. você pode querer substituir alguns diálogos.

## Estrutura do projeto:
```
📦21 <!-- Pasta principal -->
┣ 📂src <!-- Pasta de arquivos fontes -->
┃ ┣ 📂cards <!-- Pasta de arquivos de cartas -->
┃ ┃ ┗ 📜generateCards.js <!-- Arquivo de função para gerar cartas -->
┃ ┣ 📂game <!--- Pasta de arquivos de jogo -->
┃ ┃ ┣ 📜gameState.js <!-- Arquivo de estado do jogo -->
┃ ┃ ┣ 📜handleGameStateGroup.js <!-- Arquivo de manipulação de estado de jogo em grupo -->
┃ ┃ ┣ 📜handleGameStateSolo.js <!-- Arquivo de manipulação de estado de jogo individual -->
┃ ┃ ┗ 📜handlePlayerStateGroup.js <!-- Arquivo de manipulação de estado de jogador em grupo -->
┃ ┣ 📂img <!-- Pasta de imagens -->
┃ ┃ ┗ 📜joker.png <!-- Imagem de joker. Você pode usar a sua imagem de joker -->
┃ ┗ 📂utils <!-- Pasta de arquivos de utilitários -->
┃ ┃ ┣ 📜cardUtils.js <!-- Arquivo de utilitários de cartas -->
┃ ┃ ┣ 📜constants.js <!-- Arquivo de constantes. você pode querer substituir alguns valores. -->
┃ ┃ ┣ 📜gameMessages.js <!-- Arquivo de mensagens de jogo -->
┃ ┃ ┣ 📜gameUtils.js <!-- Arquivo de utilitários de jogo -->
┃ ┃ ┣ 📜helpMenu.js <!-- Arquivo de menu de ajuda -->
┃ ┃ ┗ 📜utilsArks.js <!-- Arquivo de utilitários para parsear a string Arks -->
┣ 📜.game <!-- Arquivo de indetificação no menu -->
┣ 📜index.js <!-- Arquivo principal -->
┣ 📜README.md <!-- Arquivo de README -->
┗ 📜utils.json <!-- Arquivo de configuração -->
```

# Autor
Meu GitHub: [Leonardo](https://github.com/LeonardoConstantino)

#### Se precisar de alguma informação sobre o projeto estou a disposição, avise-me!
