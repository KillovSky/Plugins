# Informações extras sobre o jogo:

## Estrutura do projeto:

Abaixo eta a lista de arquivos e pastas do projeto.
Você pode alterar o que quiser, mas lembre-se de que o arquivo principal é o index.js

### Principais arquivos que você pode querer alterar:

<img src="./src/img/joker.png" style='float: right' width=50 alt="Imagem de joker">

- **joker.png** - ```/21/src/img/joker.png``` - Imagem de joker. Você pode usar a sua imagem de joker. É recomendado que seja uma imagem quadrada e de 100x100px no formato png. Fora disso você tera que alterar o código para que a imagem seja carregada corretamente.

- **constants.js** - ```/21/src/utils/constants.js``` - Arquivo de constantes. você pode querer substituir alguns valores. Como o nome do seu bot na carta coringa. no máximo 10 caracteres.

- **gameMessages.js** - ```/21/src/utils/gameMessages.js``` - Arquivo de mensagens de jogo. você pode querer substituir alguns diálogos.

## Pastas e arquivos do projeto:
```
📦21                              # Pasta principal
┣ 📂src                           # Arquivos fontes
┃ ┣ 📂cards                       # Arquivos de cartas
┃ ┃ ┗ 📜generateCards.js          # Funções para gerar cartas
┃ ┣ 📂game                        # Arquivos de estado e manipulação
┃ ┃ ┣ 📜gameState.js              # Estado do jogo
┃ ┃ ┣ 📜handleGameStateGroup.js   # Manipulação em grupo
┃ ┃ ┣ 📜handleGameStateSolo.js    # Manipulação em jogador solo
┃ ┃ ┗ 📜handlePlayerStateGroup.js # Manipulação em jogador grupo
┃ ┣ 📂img                         # Pasta de imagens
┃ ┃ ┗ 📜joker.png                 # Imagem de joker
┃ ┗ 📂utils                       # Arquivos de utilitários
┃ ┃ ┣ 📜cardUtils.js              # Utilitários de cartas
┃ ┃ ┣ 📜constants.js              # Constantes
┃ ┃ ┣ 📜gameMessages.js           # Mensagens de jogo
┃ ┃ ┣ 📜gameUtils.js              # Utilitários de jogo
┃ ┃ ┣ 📜helpMenu.js               # Menu de ajuda
┃ ┃ ┗ 📜utilsArks.js              # Utilitários para a string Arks
┣ 📜.game                         # Arquivo de identificação no menu
┣ 📜index.js                      # Arquivo principal
┣ 📜EXTRAS.md                     # Arquivo de EXTRAS
┗ 📜utils.json                    # Arquivo de configuração
```

# Notas das versões

## version: 0.1.2
- Correção no sistema de pontos do jogo, em alguns casos o jogador recebia valores errados.

## version: 0.1.1
- O README foi atualizado.

- Corrigido bug de não conseguir entrar em uma partida em grupo não finalizada.

- Adicionado estilização nas mensagens do jogo e nas mensagens de ajuda.

- Adicionado comando para ver quem esta jogando em uma partida em grupo {prefixo}21 -jogadores.

- Adicionado sistema de ganhos e perdas, as partidas agora valem **Í-Coins!**.

- A imagem do joker agora é uma imagem mais neutra.

- Alterado o nome do joker para "Joker", no arquivo de configuração.

## version: 0.1.0
- Jogo disponibilizado com funções básicas de jogo em grupo e individual.

### TODO
- Adicionar ranking de jogadores
- Adicionar sistema para punir jogadores inativos nos jogos em grupo.

#### Se precisar de alguma informação sobre o projeto estou a disposição, avise-me!