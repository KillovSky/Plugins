# Leia aqui

Abaixo eta a lista de arquivos e pastas do projeto.
Você pode alterar o que quiser, mas lembre-se de que o arquivo principal é o index.js

### Principais arquivos que você pode querer alterar:

- joker.png - /21/src/img/joker.png - Imagem de joker. Você pode usar a sua imagem de joker

- constants.js - /21/src/utils/constants.js - Arquivo de constantes. você pode querer substituir alguns valores.

- gameMessages.js - /21/src/utils/gameMessages.js - Arquivo de mensagens de jogo. você pode querer substituir alguns valores.

## Estrutura do projeto:

📦21 <!-- Pasta principal -->
┣ 📂src <!-- Pasta de arquivos fontes -->
┃ ┣ 📂cards <!-- Pasta de arquivos de cartas -->
┃ ┃ ┗ 📜generateCards.js <!-- Arquivo de função para gerar cartas -->
┃ ┣ 📂game <!--- Pasta de arquivos de jogo -->>
┃ ┃ ┣ 📜gameState.js <!-- Arquivo de estado do jogo -->
┃ ┃ ┣ 📜handleGameStateGroup.js <!-- Arquivo de manipulação de estado de jogo em grupo -->
┃ ┃ ┣ 📜handleGameStateSolo.js <!-- Arquivo de manipulação de estado de jogo individual -->
┃ ┃ ┗ 📜handlePlayerStateGroup.js <!-- Arquivo de manipulação de estado de jogador em grupo -->
┃ ┣ 📂img <!-- Pasta de imagens -->
┃ ┃ ┗ 📜joker.png <!-- Imagem de joker. Você pode usar a sua imagem de joker -->
┃ ┗ 📂utils <!-- Pasta de arquivos de utilitários -->
┃ ┃ ┣ 📜cardUtils.js <!-- Arquivo de utilitários de cartas -->
┃ ┃ ┣ 📜constants.js <!-- Arquivo de constantes. você pode querer substituir alguns valores. -->
┃ ┃ ┣ 📜gameMessages.js <!-- Arquivo de mensagens de jogo -->
┃ ┃ ┣ 📜gameUtils.js <!-- Arquivo de utilitários de jogo -->
┃ ┃ ┣ 📜helpMenu.js <!-- Arquivo de menu de ajuda -->
┃ ┃ ┗ 📜utilsArks.js <!-- Arquivo de utilitários para parsear a string Arks -->
┣ 📜.game <!-- Arquivo de indetificação no menu -->
┣ 📜index.js <!-- Arquivo principal -->
┣ 📜README.md <!-- Arquivo de README -->
┗ 📜utils.json <!-- Arquivo de configuração -->

Meu GitHub: [Leonardo](https://github.com/LeonardoConstantino)